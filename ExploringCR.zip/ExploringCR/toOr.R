# 读取数据
data <- read.csv("mnt/data/sports_data.csv")

# 创建一个新的数据框 OrdinalData，结构与 data 相同


#delete perceived recovery=-0.01
data <- data%>% filter(perceivedrecovery > 0)
data <- data%>% filter(perceivedtrainingSuccess > 0)
data <- data%>% filter(perceivedexertion > 0)


OrdinalData <- data  # 将 data 数据框赋值给 OrdinalData
#数据预处理

#Q2 <- quantile(data$perceivedrecovery[data$perceivedrecovery != 0], 0.50)  # 中位数
#Q3 <- quantile(data$perceivedrecovery[data$perceivedrecovery != 0], 0.75)  # 第三四分位数

# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$totalkm <- ifelse(data$totalkm < 11, 0, 
                              ifelse(data$totalkm >= 11 & data$totalkm < 14.5, 1, 2))
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$kmhigh <- ifelse(data$kmhigh < 4.3, 0, 
                             ifelse(data$kmhigh >= 4.3 & data$kmhigh < 6, 1, 2))
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$kmmidlle <- ifelse(data$kmmidlle < 6, 0, 
                               ifelse(data$kmmidlle >= 6 & data$kmmidlle < 8, 1, 2))
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$kmsprinting <- ifelse(data$kmsprinting < 1, 0, 
                                  ifelse(data$kmsprinting >= 1 & data$kmsprinting < 1.2, 1, 2))
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$strengthtraining <- ifelse(data$strengthtraining < 1, 0, 1)
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$perceivedtrainingSuccess <- ifelse(data$perceivedtrainingSuccess < 0.72, 0, 
                                               ifelse(data$perceivedtrainingSuccess >= 0.72 & data$perceivedtrainingSuccess < 0.8, 1, 2))
# hoursalternative
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$hoursalternative <- ifelse(data$hoursalternative < 1, 0, 
                                       ifelse(data$hoursalternative >= 1 & data$hoursalternative < 1.58, 1, 2))
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$perceivedexertion <- ifelse(data$perceivedexertion < 0.44, 0, 
                                        ifelse(data$perceivedexertion >= 0.44 & data$perceivedexertion < 0.61, 1, 2))
# 使用 ifelse() 函数根据 totalkm 的值进行分组并赋值
OrdinalData$perceivedrecovery <- ifelse(data$perceivedrecovery < 0.3, 0, 
                                        ifelse(data$perceivedrecovery >= 0.3 & data$perceivedrecovery < 0.46, 1, 2))
OrdinalData[] <- lapply(OrdinalData, function(x) as.integer(as.numeric(x)))
save(OrdinalData, file=file.path("./mnt/data","OrdinalDataT.RData"))

