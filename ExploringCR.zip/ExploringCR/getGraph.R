library(ggplot2)
library(dplyr)

library(ggplot2)
library(dplyr)

# 设置颜色区分路径
path_colors <- c("Path 1" = "#1b9e77",
                 "Path 2" = "#d95f02",
                 "Path 3" = "#7570b3")

# 创建一个简化列用于颜色映射
effects$PathSimple <- factor(c(rep("Path 1", 3), rep("Path 2", 3), rep("Path 3", 3)))

# 保持横轴顺序
effects$EffectType <- factor(effects$EffectType, levels = c("Indirect", "Direct", "Total"))

# position_dodge 控制每个类型下三条路径的间距
dodge <- position_dodge(width = 0.3)

p <- ggplot(effects, aes(x = EffectType, y = Estimate, color = PathSimple)) +
  geom_point(size = 3, position = dodge) +
  geom_errorbar(aes(ymin = CI_low, ymax = CI_high),
                width = 0.2, size = 1, position = dodge) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  scale_color_manual(values = path_colors) +
  labs(title = "Causal Pathway Effects with 95% CI",
       x = "Effect Type",
       y = "Effect Estimate (with 95% CI)",
       color = "Path") +
  theme_classic(base_size = 14) +
  theme(
    axis.text.x = element_text(size = 12),
    legend.position = "top",
    legend.title = element_text(face = "bold")
  )

print(p)

# 保存高分辨率图像
ggsave("Figure/forest_effects.tiff", plot = p, dpi = 600, width = 8, height = 5, units = "in", compression = "lzw")
ggsave("Figure/forest_effects.pdf", plot = p, width = 8, height = 5, units = "in")
