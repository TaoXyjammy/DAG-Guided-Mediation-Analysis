########### Psychological Application ###########
# Required packages
library(BiDAG)
library(pcalg)
library(bnlearn)
library(corrplot)
library(igraph)
library(abind)
source("./R/OrdinalEffects.R")
source("./R/OrdinalScore.R")

insertSource("./R/spacefns.R",package = "BiDAG")
insertSource("./R/usrscorefns.R",package = "BiDAG")
insertSource("./R/initpar.R",package = "BiDAG")
insertSource("./R/scoreagainstdag.R",package = "BiDAG")

# Data processing
load("./mnt/data/OrdinalDataT.RData")
n <- ncol(OrdinalData)
N <- nrow(OrdinalData)

load("Results_Boot_sport.RData")

#OWEN Methods
Effects<-list()#results就是上面Results_Boot_Sportinjury数据
system.time(for (i in 1:500){
  OSEMfit<-results[[i]]
  cuts <-OSEMfit[["param"]][["cuts"]]
  S<- OSEMfit[["param"]][["Sigma_hat"]]
  DAG <- as.matrix(OSEMfit$DAG)
  Chol <- getCov(S,DAG)
  B <- Chol[[1]]
  Vchol <- Chol[[2]]
  Effects[[i]] <-getallEffects(mu=rep(0,n),B,V=Vchol,cuts,intType = "OWEN")
})


#save Effects to a file 
save(Effects, file = file.path("./mnt/data","Sport_Effects.RData"))

load("./mnt/data/Sport_Effects.RData")

# Point estimates
OSEMfit_point <- ordinalStructEM(n, OrdinalData,
                                 usrpar = list(penType = "other",
                                               L = 5,
                                               lambda = 6))

g <- as_graphnel(graph_from_adjacency_matrix(OSEMfit_point$DAG))
cpdag_OSEM <- dag2cpdag(g)
png(paste0("OSEM_CDDAG_Pysch",i,".png"), width = 465, height = 225, units='mm', res = 300)
plot(as(cpdag_OSEM, "graphNEL"),main = "Cpdag estimated with OSEM")
dev.off()

save(OSEMfit_point,file = file.path("./mnt/data","OSEMfit_point.RData"))

# Get strengths arrows 
#Credits: OSEM code source application 
res<-list()
for (i in 1:500){
  res[[i]]<- results[[i]]$maxtrace[[1]]$DAG
}
newarray<-array(NA, dim=c(n,n,500))
for (i in 1:n){
  for (j in 1:n){
    for (k in 1:500){
      newarray[i,j,k]<-res[[k]][i,j]
    }
  }
}
res_cpdag<-newarray
for (j in c(1:500)) {
  res_cpdag[,,j] <- dag2cpdag(newarray[,,j])
}
res_OSEM<-res_cpdag
save(res_OSEM, file=file.path("./mnt/data","Res_OSEM_sport.RData"))
load("./mnt/data/Res_OSEM_sport.RData")

get_strength <- function (c, cboot) {
  n <- nrow(c)
  for (i in c(1:n)) {
    for (j in c(1:n)) {
      if (c[i,j] & i != j) {
        c[i,j] <- mean(apply(cboot,3,function (A) if ((A[i,j] + A[j,i]) == 1) {A[i,j]} else {A[i,j] / 2}))
      }
    }
  }
  return(c)
}

pdf("cpdag_OSEM.pdf", width = 8, height = 6)

# 绘制图形
cpdag_OSEM <- as(OSEMfit_point$DAG,"matrix")
cpdag_OSEM <- get_strength(cpdag_OSEM, res_OSEM)
corrplot(cpdag_OSEM, method = "shade", is.corr = FALSE,
         tl.col = "grey", col.lim = c(0,1),
         mar = c(1,0,0,0)+0.5, addgrid.col = "lightgrey", diag=FALSE)
#title(sub = "OSEM")

# 关闭 PDF 输出
dev.off()

